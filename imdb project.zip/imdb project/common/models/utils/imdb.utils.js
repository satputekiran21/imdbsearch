const { isNull, getRows  } = require('./common.utils');

    const ImdbSearch = (count, page, search) => {
        return new Promise(async(resolve, reject) => {
            try {
    
                let appendQuery = ''
                let limitQuery = ''
                let orderQuery = ' order by id asc'
                if (!isNull(search)) {
                    appendQuery += ` where LOWER(primarytitle) LIKE LOWER('%${search}%')`;
                }
    
                let page_no = (isNull(page) || isNull(parseInt(page))) ? 1 : parseInt(page);
                let limit = (isNull(count) || isNull(parseInt(count))) ? 10 : parseInt(count);
                let offset = 0;
    
                offset = (parseInt(page_no) - 1) * limit;
                limitQuery += ` LIMIT ${limit} OFFSET ${offset} `
    
                let searchQuery = `SELECT id,
                                    tconst,
                                    titletype,
                                    primarytitle,
                                    originaltitle,
                                    isadult,
                                    startyear,
                                    endyear,
                                    runtimeminutes,
                                    genres
                                FROM imdb  ${appendQuery} ${limitQuery} `;
    
                let countQuery = `select
                                        count(*)
                                    FROM imdb`;
    
                console.log("searchQuery::", searchQuery)
                console.log("countQuery::", countQuery)
    
                let res = await Promise.all([getRows(searchQuery), getRows(countQuery)])
                console.log("res:::", res)
                const { 0: searchres, 1: rawCounts} = res;
                  let total_pages = 0;
                  if (!isNull(rawCounts) && !isNull(rawCounts[0].count)) {
                    total_pages = Math.ceil(rawCounts[0].count / limit);
                  }
                  let meta = {
                    "records": searchres,
                    "totalPages" : total_pages,
                    "totalCount" :rawCounts[0].count
                  }
    
                resolve ({"success": true, "msg": 'imdb details', "data": meta})
            }
            catch (error) {
                console.log("err::", error)
                reject({"success": false, "msg":'error getting imdb details', "data": error})
            }
        })
    }

    module.exports = { ImdbSearch }
