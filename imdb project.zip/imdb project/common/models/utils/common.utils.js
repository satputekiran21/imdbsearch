
const app = require('../../../server/server');
const Pool = require('pg-pool');
var datasource = app.datasources.postgresdb.connector;
const pool = new Pool({
  "host": "",
  "port": "",
  "database": "",
  "password": "",
  "user": "",
  "url": "postgres://fvqckbwx:o76Jus45pl3MHfOIUZ4MU3wW6yOM949Q@tiny.db.elephantsql.com/fvqckbwx",
  "name": "postgresdb",
  "connector": "postgresql"
});


const isNull = function (val) {
    if (typeof val === 'string') { val = val.trim(); val = val.toLowerCase(); }
    if (typeof val === 'number' && val == 0) { return true; }
    if (typeof val === 'object' && (JSON.stringify(val) === '{}' || JSON.stringify(val) === '[]')) { return true; }
    if (val === '' || val === null || typeof val === 'undefined' || val === '' || val === 'undefined' || val === 'null' || typeof val === undefined) {
      return true;
    } else {
      return false;
    }
};

const getRows = (query, params = [], client = '') => {
    return new Promise ((resolve, reject) => {
      //console.log("ksdsakd::",query)
      let con = client ? client : datasource;
      // console.log("datasource", datasource)
      con.query(query, params, (err, res) => {
        if (err) {
          console.log("ERROR in query::", query, params)
          reject(err);
        } else {
          if (client) {
            resolve(res.rows);
          } else {
            resolve(res);
          }
        }
      })
    });
  };

  module.exports = { isNull, getRows }

