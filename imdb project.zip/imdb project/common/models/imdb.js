'use strict';
const { ImdbSearch } = require('../models/utils/imdb.utils');

module.exports = function(Imdb) {

  Imdb.Imdbrating = async(count, page, search) => {
    console.log("Imdb");
      const result = await ImdbSearch(count, page, search);
      return result;
  }
  
  Imdb.remoteMethod(
      'Imdbrating', {
     
          description: 'Imdbrating',
          accepts: [
            {
              arg: 'count',
              type: 'number',
              http: {
                source: 'query'
              }
            },
            {
              arg: 'page',
              type: 'number',
              http: {
                source: 'query'
              }
            },
            {
              arg: 'search',
              type: 'string',
              http: {
                source: 'query'
              }
            }
          ],
          returns: {
              arg: 'result',
              type: 'object',
              root: true,
              description: 'Imdbrating'
          },
          http: {
              verb: 'get',
              path: '/imdbsearch'
          }
      }
  );



      Imdb.disableRemoteMethodByName("prototype.patchAttributes", true);
      Imdb.disableRemoteMethodByName("create", true);
      Imdb.disableRemoteMethodByName("upsert", true);
      Imdb.disableRemoteMethodByName("updateAll", true);
      Imdb.disableRemoteMethodByName("updateAttributes", false);
      Imdb.disableRemoteMethodByName("find", true);
      Imdb.disableRemoteMethodByName("findById", true);
      Imdb.disableRemoteMethodByName("findOne", true);
      Imdb.disableRemoteMethodByName("deleteById", true);
      Imdb.disableRemoteMethodByName("confirm", true);
      Imdb.disableRemoteMethodByName("count", true);
      Imdb.disableRemoteMethodByName("exists", true);
      Imdb.disableRemoteMethodByName("replaceById", true);
      Imdb.disableRemoteMethodByName("replaceOrCreate", true);
      Imdb.disableRemoteMethodByName("upsertWithWhere", true);
      Imdb.disableRemoteMethodByName("createChangeStream", true);

      




};
